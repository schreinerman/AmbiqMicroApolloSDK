
Important Note for Flash-Debugging:
===================================

The file "*.FLM" is flash loading file for the microcontroller. 
Please copy this file to the following directory

  "[Drive]:\Keil\ARM\Flash"

