
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'apollo2_oled_ugui' 
 * Target:  'AMAPH1KK-KBR_Release' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "apollo2.h"


#endif /* RTE_COMPONENTS_H */
