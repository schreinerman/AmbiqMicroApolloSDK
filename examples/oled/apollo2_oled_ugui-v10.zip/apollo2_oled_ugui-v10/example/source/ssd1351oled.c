/******************************************************************************

Copyright (C) 2013-2017, Fujitsu Electronics Europe GmbH or a               
subsidiary of Fujitsu Electronics Europe GmbH.  All rights reserved.        
                                                                            
This software, including source code, documentation and related             
materials ("Software"), is owned by Fujitsu Electronics Europe GmbH or      
one of its subsidiaries ("Fujitsu").
                                                                            
If no EULA applies, Fujitsu hereby grants you a personal, non-exclusive,    
non-transferable license to copy, modify, and compile the                   
Software source code solely for use in connection with Fujitsu's            
integrated circuit products.  Any reproduction, modification, translation,  
compilation, or representation of this Software except as specified         
above is prohibited without the express written permission of Fujitsu.      
                                                                            
Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO                        
WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING,                        
BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED                                
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A                             
PARTICULAR PURPOSE. Fujitsu reserves the right to make                      
changes to the Software without notice. Fujitsu does not assume any         
liability arising out of the application or use of the Software or any      
product or circuit described in the Software. Fujitsu does not              
authorize its products for use in any products where a malfunction or       
failure of the Fujitsu product may reasonably be expected to result in      
significant property damage, injury or death ("High Risk Product"). By      
including Fujitsu's product in a High Risk Product, the manufacturer        
of such system or application assumes all risk of such use and in doing     
so agrees to indemnify Fujitsu against all liability.                       

 ******************************************************************************/
/******************************************************************************/
/** \file Ssd1351Oled.c
 **
 ** A detailed description is available at 
 ** @link Ssd1351OledGroup OLED with SSD1351 Driver description @endlink
 **
 ** History:
 **   - 2019-01-21  V1.0  MSc  First Version
 **   - 2019-04-02  V1.1  MSc  Adding partly updating display
 *****************************************************************************/
#define __SSD1351OLED_C__
/*****************************************************************************/
/* Include files                                                             */
/*****************************************************************************/

#include "ssd1351oled.h"

/*****************************************************************************/
/* Local pre-processor symbols/macros ('#define')                            */
/*****************************************************************************/


/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/



/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/


/*****************************************************************************/
/* Local variable definitions ('static')                                     */
/*****************************************************************************/

                                      //Commannd,                       DataLen,    Data
static const uint8_t au8InitData[] = {  SSD1351OLED_CMD_COMMANDLOCK,       1,       0x12,       // command lock
                                        SSD1351OLED_CMD_COMMANDLOCK,       1,       0xb1,       // command lock
                                        SSD1351OLED_CMD_DISPLAYOFF,        0,                   // display off
                                        SSD1351OLED_CMD_DISPLAYALLOFF,     0,                   // normal display mode
                                        SSD1351OLED_CMD_SETCOLUMN,         2,       0x00, 0x7f, //column address start 00, column address end 95
                                        SSD1351OLED_CMD_SETROW,            2,       0x00, 0x7f, //row address start 00, row address end 63
                                        SSD1351OLED_CMD_CLOCKDIV,          1,       0xF1,
                                        SSD1351OLED_CMD_MUXRATIO,          1,       0x7F,
                                        SSD1351OLED_CMD_SETREMAP,          1,       0x74,       //set re-map & data format, horizontal address increment
                                        SSD1351OLED_CMD_STARTLINE,         1,       0x00,       //set display start line 00
                                        SSD1351OLED_CMD_DISPLAYOFFSET,     1,       0x00,       //set display offset
                                        SSD1351OLED_CMD_FUNCTIONSELECT,    1,       0x01,    
                                        SSD1351OLED_CMD_SETVSL,            3,       0xA0, 0xB5, 0x55,
                                        SSD1351OLED_CMD_CONTRASTABC,       3,       0xC8, 0x80, 0xC0,
                                        SSD1351OLED_CMD_CONTRASTMASTER,    1,       0x0F,
                                        SSD1351OLED_CMD_PRECHARGE,         1,       0x32,
                                        SSD1351OLED_CMD_DISPLAYENHANCE,    3,       0xA4, 0x00, 0x00,
                                        SSD1351OLED_CMD_PRECHARGELEVEL,    1,       0x17,
                                        SSD1351OLED_CMD_PRECHARGE2,        1,       0x01,
                                        SSD1351OLED_CMD_VCOMH,             1,       0x05,
                                        SSD1351OLED_CMD_NORMALDISPLAY,     0
                                      };


static stc_ssd1351oled_handle_t* pstcDefaultHandle = NULL;

/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/

static void writecommand(stc_ssd1351oled_handle_t* pstcHandle, uint8_t u8Command);
static void writeDataByte(stc_ssd1351oled_handle_t* pstcHandle, uint8_t u8Data);
static void writeDataBuffer(stc_ssd1351oled_handle_t* pstcHandle, uint8_t* pu8Data, uint32_t u32Len);


/*****************************************************************************/
/* Function implementation - global ('extern') and local ('static')          */
/*****************************************************************************/

/**
 *****************************************************************************
 ** 
 ** \brief Link to ms delay function defined externally
 **
 ** \details Link to ms delay function defined externally, for example using CMSIS Systick:
 **
 ** Create a global counter variable:
 ** @code
 **   volatile uint32_t u32Counter;  //ms counter
 ** @endcode
 **
 ** Initialize the Systick Timer:
 ** @code  
 **   SystemCoreClockUpdate();                //update clock variable SystemCoreClock (defined by CMSIS)
 **   SysTick_Config(SystemCoreClock / 1000); //setup 1ms SysTick (defined by CMSIS)
 ** @endcode  
 **
 ** Create the Systick ISR:
 ** @code
 **   void SysTick_Handler(void)
 **   {
 **       u32Counter++;
 **   }
 ** @endcode
 **
 ** Create the delay function:
 ** @code
 **   void delay(uint32_t delayMs) 
 **   {
 **       uint32_t u32End = u32Counter;
 **       u32End += delayMs;
 **       while(u32End != u32Counter) __NOP();
 **   }
 ** @endcode
 **
 *****************************************************************************/                                     
extern void delay(uint32_t delayMs);

/**
 *****************************************************************************
 ** 
 ** \brief Weak ms delay function if not defined externally
 **
 ** \param delayMs in theory ms but has to be adjusted depending on the used MCU
 **
 *****************************************************************************/  
__WEAK void delay(uint32_t delayMs)
{
    volatile int i;
    while(delayMs--)
    {
        for(i = 0;i<10000;i++);
    }
}

/**
 *****************************************************************************
 ** 
 ** \brief Write command byte via SPI
 **
 ** \param pstcHandle OLED handle
 **
 ** \param u8Command  Command
 **
 *****************************************************************************/  
static void writecommand(stc_ssd1351oled_handle_t* pstcHandle, uint8_t u8Command)
{
    //
    // wait while SPI is not ready
    //
    while(pstcHandle->pfSpiCheckReady(pstcHandle->SpiHandle) != TRUE) 
    {
    }

    //
    // if CS is used as GPIO, pull CS low
    //
    if (pstcHandle->Gpio.CS != SSD1351OLED_GPIO_UNUSED) 
    {
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.CS,FALSE);
    }

    //
    // if DC is used as GPIO, pull DC low
    //
    if (pstcHandle->Gpio.DC != SSD1351OLED_GPIO_UNUSED) 
    {
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.DC,FALSE);
    }

    //
    // write data via SPI
    //
    pstcHandle->pfSpiWrite(pstcHandle->SpiHandle,pstcHandle->u32Chipselect,&u8Command,1);

    //
    // wait while SPI is not ready
    //
    while(pstcHandle->pfSpiCheckReady(pstcHandle->SpiHandle) != TRUE) 
    {
    }

    //
    // if CS is used as GPIO, pull CS high
    //
    if (pstcHandle->Gpio.DC != SSD1351OLED_GPIO_UNUSED) 
    {
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.DC,TRUE);
    }

    //
    // if DS is used as GPIO, pull DS high
    //
    if (pstcHandle->Gpio.CS != SSD1351OLED_GPIO_UNUSED) 
    {
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.CS,TRUE);
    }
}

/**
 *****************************************************************************
 ** 
 ** \brief Write Data byte via SPI
 **
 ** \param pstcHandle OLED handle
 **
 ** \param u8Data  Data byte
 **
 *****************************************************************************/  
static void writeDataByte(stc_ssd1351oled_handle_t* pstcHandle, uint8_t u8Data)
{
    //
    // if CS is used as GPIO, wait SPI is ready and pull CS low
    // otherwise CS timing is handled in SPI HW
    //
    if (pstcHandle->Gpio.CS != SSD1351OLED_GPIO_UNUSED) 
    {
        while(pstcHandle->pfSpiCheckReady(pstcHandle->SpiHandle) != TRUE) 
        {
        }
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.CS,FALSE);
    }

    //
    // write data via SPI
    //
    pstcHandle->pfSpiWrite(pstcHandle->SpiHandle,pstcHandle->u32Chipselect,&u8Data,1);

    //
    // if CS is used as GPIO, wait SPI is ready/is finished and pull CS high
    // otherwise CS timing is handled in SPI HW
    //
    if (pstcHandle->Gpio.CS != SSD1351OLED_GPIO_UNUSED) 
    {
        while(pstcHandle->pfSpiCheckReady(pstcHandle->SpiHandle) != TRUE) 
        {
        }
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.CS,TRUE);
    }
}

/**
 *****************************************************************************
 ** 
 ** \brief Write Data buffer via SPI
 **
 ** \param pstcHandle OLED handle
 **
 ** \param pu8Data Pointer to data buffer
 **
 ** \param u32Len Buffer size
 **
 *****************************************************************************/  
static void writeDataBuffer(stc_ssd1351oled_handle_t* pstcHandle, uint8_t* pu8Data, uint32_t u32Len)
{
    //
    // if CS is used as GPIO, wait SPI is ready and pull CS low
    // otherwise CS timing is handled in SPI HW
    //
    if (pstcHandle->Gpio.CS != SSD1351OLED_GPIO_UNUSED) 
    {
        while(pstcHandle->pfSpiCheckReady(pstcHandle->SpiHandle) != TRUE) 
        {
        }
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.CS,FALSE);
    }

    //
    // write data via SPI
    //
    pstcHandle->pfSpiWrite(pstcHandle->SpiHandle,pstcHandle->u32Chipselect,pu8Data,u32Len);

    //
    // if CS is used as GPIO, wait SPI is ready/is finished and pull CS high
    // otherwise CS timing is handled in SPI HW
    //
    if (pstcHandle->Gpio.CS != SSD1351OLED_GPIO_UNUSED) 
    {
        while(pstcHandle->pfSpiCheckReady(pstcHandle->SpiHandle) != TRUE) 
        {
        }
        pstcHandle->pfGpioSetClear(pstcHandle->Gpio.CS,TRUE);
    }
}

/**
 *****************************************************************************
 ** 
 ** \brief Turn OLED display on
 **
 ** \param pstcHandle OLED handle
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_DisplayOn(stc_ssd1351oled_handle_t* pstcHandle)  
{
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }
    writecommand(pstcHandle,SSD1351OLED_CMD_DISPLAYON);
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Turn OLED display off
 **
 ** \param pstcHandle OLED handle
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_DisplayOff(stc_ssd1351oled_handle_t* pstcHandle)  
{
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }
    writecommand(pstcHandle,SSD1351OLED_CMD_DISPLAYOFF);
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Select default display handle
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_SetDefaultHandle(stc_ssd1351oled_handle_t* pstcHandle)
{
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }

    pstcDefaultHandle = pstcHandle;
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Init OLED display 
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_Init(stc_ssd1351oled_handle_t* pstcHandle)
{
    int i = 0;
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }

    if (pstcDefaultHandle == NULL) pstcDefaultHandle = pstcHandle;
     
    pstcHandle->FrameBufferUpdate.bNeedsUpdate = TRUE;
    pstcHandle->FrameBufferUpdate.xmin = SSD1351OLED_WIDTH;
    pstcHandle->FrameBufferUpdate.xmax = 0;
    pstcHandle->FrameBufferUpdate.ymin = SSD1351OLED_HEIGHT;
    pstcHandle->FrameBufferUpdate.ymax = 0;


    //
    // Reset OLED
    //
    pstcHandle->pfGpioSetClear(pstcHandle->Gpio.RST,FALSE);
    delay(20);
    pstcHandle->pfGpioSetClear(pstcHandle->Gpio.RST,TRUE);
    delay(20);

    //
    // Execute initialization commands
    //
    while(i < sizeof(au8InitData))
    {
        writecommand(pstcHandle,au8InitData[i]);
        writeDataBuffer(pstcHandle,(uint8_t*)&au8InitData[i+2],au8InitData[i+1]);
        i = i + au8InitData[i + 1] + 2;
    }

    //
    // Clear dispay
    //
    Ssd1351Oled_FillColor(pstcHandle,(stc_color_t){0x0000},enSsd1351OledModeDirect);

    //
    // Turn display on
    //
    Ssd1351Oled_DisplayOn(pstcHandle);
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Print framebuffer to OLED 
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_UpdateFullFramebuffer(stc_ssd1351oled_handle_t* pstcHandle)
{
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }
    Ssd1351Oled_RamAddress(pstcHandle);
    writecommand(pstcHandle,SSD1351OLED_CMD_WRITERAM);
    writeDataBuffer(pstcHandle,(uint8_t*)&pstcHandle->pFrameBuffer[0],sizeof(stc_color_t)*SSD1351OLED_WIDTH*SSD1351OLED_HEIGHT);
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Print framebuffer to OLED only for the changed region
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/ 
void Ssd1351Oled_UpdatePartFramebuffer(stc_ssd1351oled_handle_t* pstcHandle)
{
    if (pstcHandle->FrameBufferUpdate.bNeedsUpdate == TRUE)
    {
        Ssd1351Oled_UpdateFramebufferWindow(pstcHandle,pstcHandle->FrameBufferUpdate.xmin,pstcHandle->FrameBufferUpdate.ymin,pstcHandle->FrameBufferUpdate.xmax,pstcHandle->FrameBufferUpdate.ymax);
        pstcHandle->FrameBufferUpdate.xmin = SSD1351OLED_WIDTH;
        pstcHandle->FrameBufferUpdate.xmax = 0;
        pstcHandle->FrameBufferUpdate.ymin = SSD1351OLED_HEIGHT;
        pstcHandle->FrameBufferUpdate.ymax = 0;
        pstcHandle->FrameBufferUpdate.bNeedsUpdate = FALSE;
    }
}

/**
 *****************************************************************************
 ** 
 ** \brief Print framebuffer to OLED 
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 ** 
 ** \param xmin smallest x value
 ** 
 ** \param ymin smallest y value
  ** 
 ** \param xmax highest x value
 ** 
 ** \param ymax highest y value
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_UpdateFramebufferWindow(stc_ssd1351oled_handle_t* pstcHandle,uint16_t xmin, uint16_t ymin, uint16_t xmax, uint16_t ymax)
{
    uint16_t i;
    uint16_t datalen;
    uint8_t au8Data[2];
    uint16_t* pFb = (uint16_t*)&pstcHandle->pFrameBuffer[0];
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }
    if (xmax < (SSD1351OLED_WIDTH-1)) xmax++;
    if (ymax < (SSD1351OLED_HEIGHT-1)) ymax++;
    if (xmin > 0) xmin--;
    if (ymin > 0) ymin--;
    datalen = xmax - xmin + 1;
    au8Data[0] = xmin;
    au8Data[1] = xmax;
    writecommand(pstcHandle,SSD1351OLED_CMD_SETCOLUMN);
    writeDataBuffer(pstcHandle,(uint8_t*)&au8Data[0],2);
    au8Data[0] = ymin;
    au8Data[1] = ymax;
    writecommand(pstcHandle,SSD1351OLED_CMD_SETROW);
    writeDataBuffer(pstcHandle,(uint8_t*)&au8Data[0],2);

    writecommand(pstcHandle,SSD1351OLED_CMD_WRITERAM);

    //writeDataBuffer(pstcHandle,&pFb[(ymin * SSD1351OLED_WIDTH)],SSD1351OLED_WIDTH * (ymax-ymin) * 2);

    for(i = ymin;i < ymax;i++)
    {
        writeDataBuffer(pstcHandle,(uint8_t*)&pFb[(i * SSD1351OLED_WIDTH + xmin)],datalen*2);
    }
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Point to OLEDs RAM address
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_RamAddress(stc_ssd1351oled_handle_t* pstcHandle)  
{
    const uint8_t au8Data[2] = {0x00,0x7f};
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }
    writecommand(pstcHandle,SSD1351OLED_CMD_SETCOLUMN);
    writeDataBuffer(pstcHandle,(uint8_t*)&au8Data[0],2);
    writecommand(pstcHandle,SSD1351OLED_CMD_SETROW);
    writeDataBuffer(pstcHandle,(uint8_t*)&au8Data[0],2);
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Fill framebuffer / OLED with a color
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 **
 ** \param enMode Mode: enSsd1351OledModeDirect to directly update OLED, 
 **                     enSsd1351OledModeFrameBuffer to update framebuffer, 
 **                     enSsd1351OledModeFrameBufferAndUpdate to update both
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_FillColor(stc_ssd1351oled_handle_t* pstcHandle, stc_color_t stcColor, en_ssd1351oled_mode_t enMode)  
{
    uint32_t i;
    uint16_t u16Tmp = SSD1351OLED_U16_SWAP(stcColor.Data);
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }
    if (enMode == enSsd1351OledModeDirect)
    {
        Ssd1351Oled_RamAddress(pstcHandle);
        writecommand(pstcHandle,SSD1351OLED_CMD_WRITERAM);
        for(i = 0; i < (SSD1351OLED_WIDTH * SSD1351OLED_HEIGHT); i++)  
        {
            writeDataBuffer(pstcHandle,(uint8_t*)&u16Tmp,2);
        }
    } else if ((enMode == enSsd1351OledModeFrameBuffer) || (enMode == enSsd1351OledModeFrameBufferAndUpdate))
    {
        for(i = 0; i < (SSD1351OLED_WIDTH * SSD1351OLED_HEIGHT);i++)
        {
            pstcHandle->pFrameBuffer[i].Data = u16Tmp;
        }
        if (enMode == enSsd1351OledModeFrameBufferAndUpdate)
        {
            Ssd1351Oled_RamAddress(pstcHandle);
            writecommand(pstcHandle,SSD1351OLED_CMD_WRITERAM);
            writeDataBuffer(pstcHandle,(uint8_t*)&pstcHandle->pFrameBuffer[0],sizeof(stc_color_t)*SSD1351OLED_WIDTH*SSD1351OLED_HEIGHT);
        }
    }
    return Ok;
}

/**
 *****************************************************************************
 ** 
 ** \brief Fill framebuffer / OLED with a databuffer
 **
 ** \param pstcHandle pointer to OLED configuration and same time OLED handle
 **
 ** \param pData pointer to data buffer
 **
 ** \param enMode Mode: enSsd1351OledModeDirect to directly update OLED, 
 **                     enSsd1351OledModeFrameBuffer to update framebuffer, 
 **                     enSsd1351OledModeFrameBufferAndUpdate to update both
 **
 ** \return Ok on success, ErrorInvalidParameter if pstcHandle is NULL
 **
 *****************************************************************************/  
en_result_t Ssd1351Oled_FillScreen(stc_ssd1351oled_handle_t* pstcHandle, stc_color_t* pData, en_ssd1351oled_mode_t enMode)  
{
    uint32_t i;
    uint16_t u16Tmp;
    if (pstcHandle == NULL)
    {
        return ErrorInvalidParameter;
    }
    if (enMode == enSsd1351OledModeDirect)
    {
        Ssd1351Oled_RamAddress(pstcHandle);
        writecommand(pstcHandle,SSD1351OLED_CMD_WRITERAM);
        for(i = 0; i < (SSD1351OLED_WIDTH * SSD1351OLED_HEIGHT); i++)  
        {
            u16Tmp = SSD1351OLED_U16_SWAP((*pData).Data);
            writeDataBuffer(pstcHandle,(uint8_t*)&u16Tmp,2);
            pData++;
        }
    } else if ((enMode == enSsd1351OledModeFrameBuffer) || (enMode == enSsd1351OledModeFrameBufferAndUpdate))
    {
        for(i = 0; i < (SSD1351OLED_WIDTH * SSD1351OLED_HEIGHT);i++)
        {
            pstcHandle->pFrameBuffer[i].Data = SSD1351OLED_U16_SWAP((*pData).Data);
            pData++;
        }
        if (enMode == enSsd1351OledModeFrameBufferAndUpdate)
        {
            Ssd1351Oled_RamAddress(pstcHandle);
            writecommand(pstcHandle,SSD1351OLED_CMD_WRITERAM);
            writeDataBuffer(pstcHandle,(uint8_t*)&pstcHandle->pFrameBuffer[0],sizeof(stc_color_t)*SSD1351OLED_WIDTH*SSD1351OLED_HEIGHT);
        }
    }
    return Ok;
}

/**
 *********************************************************************************
 ** \brief Set pixel function writing to default display (compatible with uGUI)
 **
 ** \param x position x
 **
 ** \param y position y
 **
 ** \param c color in RGBA888 (alpha not yet used)
 **  
 ** \details uGUI set pixel function
 **  
 *********************************************************************************/
void Ssd1351Oled_SetPixelDefaultHandle(int16_t x,int16_t y,uint32_t c)
{
    static uint16_t tmp;
    if ((x >= SSD1351OLED_WIDTH) || (y >= SSD1351OLED_HEIGHT) || (x < 0) || (y < 0)) return;
    tmp =  (c >> 3) & 0x001F;
    tmp |= (c >> 5) & 0x07E0;
    tmp |= (c >> 8) & 0xF800;
    tmp = (tmp << 8) | (tmp >> 8);
    if (tmp !=  ((uint16_t*)pstcDefaultHandle->pFrameBuffer)[(x + y*SSD1351OLED_WIDTH)])
    {
        ((uint16_t*)pstcDefaultHandle->pFrameBuffer)[(x + y*SSD1351OLED_WIDTH)] = tmp;
        pstcDefaultHandle->FrameBufferUpdate.bNeedsUpdate = TRUE;
        pstcDefaultHandle->FrameBufferUpdate.xmin = MIN(x,pstcDefaultHandle->FrameBufferUpdate.xmin);
        pstcDefaultHandle->FrameBufferUpdate.ymin = MIN(y,pstcDefaultHandle->FrameBufferUpdate.ymin);
        pstcDefaultHandle->FrameBufferUpdate.xmax = MAX(x,pstcDefaultHandle->FrameBufferUpdate.xmax);
        pstcDefaultHandle->FrameBufferUpdate.ymax = MAX(y,pstcDefaultHandle->FrameBufferUpdate.ymax);
    }
}

/**
 *********************************************************************************
 ** \brief Set pixel function
 **
 ** \param x position x
 **
 ** \param y position y
 **
 ** \param c color in RGBA888 (alpha not yet used)
 **  
 ** \details uGUI set pixel function
 **  
 *********************************************************************************/
void Ssd1351Oled_SetPixel(stc_ssd1351oled_handle_t* pstcHandle, int16_t x,int16_t y,uint32_t c)
{
    static uint16_t tmp;
    if ((x >= SSD1351OLED_WIDTH) || (y >= SSD1351OLED_HEIGHT) || (x < 0) || (y < 0)) return;
    tmp =  (c >> 3) & 0x001F;
    tmp |= (c >> 5) & 0x07E0;
    tmp |= (c >> 8) & 0xF800;
    tmp = (tmp << 8) | (tmp >> 8);
    if (tmp !=  ((uint16_t*)pstcHandle->pFrameBuffer)[(x + y*SSD1351OLED_WIDTH)])
    {
        ((uint16_t*)pstcHandle->pFrameBuffer)[(x + y*SSD1351OLED_WIDTH)] = tmp;
        pstcHandle->FrameBufferUpdate.bNeedsUpdate = TRUE;
        pstcHandle->FrameBufferUpdate.xmin = MIN(x,pstcHandle->FrameBufferUpdate.xmin);
        pstcHandle->FrameBufferUpdate.ymin = MIN(y,pstcHandle->FrameBufferUpdate.ymin);
        pstcHandle->FrameBufferUpdate.xmax = MAX(x,pstcHandle->FrameBufferUpdate.xmax);
        pstcHandle->FrameBufferUpdate.ymax = MAX(y,pstcHandle->FrameBufferUpdate.ymax);
    }
}


/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/

