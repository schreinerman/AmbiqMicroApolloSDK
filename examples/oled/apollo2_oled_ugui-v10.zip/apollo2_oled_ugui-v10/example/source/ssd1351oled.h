/******************************************************************************

Copyright (C) 2013-2017, Fujitsu Electronics Europe GmbH or a               
subsidiary of Fujitsu Electronics Europe GmbH.  All rights reserved.        
                                                                            
This software, including source code, documentation and related             
materials ("Software"), is owned by Fujitsu Electronics Europe GmbH or      
one of its subsidiaries ("Fujitsu").
                                                                            
If no EULA applies, Fujitsu hereby grants you a personal, non-exclusive,    
non-transferable license to copy, modify, and compile the                   
Software source code solely for use in connection with Fujitsu's            
integrated circuit products.  Any reproduction, modification, translation,  
compilation, or representation of this Software except as specified         
above is prohibited without the express written permission of Fujitsu.      
                                                                            
Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO                        
WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING,                        
BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED                                
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A                             
PARTICULAR PURPOSE. Fujitsu reserves the right to make                      
changes to the Software without notice. Fujitsu does not assume any         
liability arising out of the application or use of the Software or any      
product or circuit described in the Software. Fujitsu does not              
authorize its products for use in any products where a malfunction or       
failure of the Fujitsu product may reasonably be expected to result in      
significant property damage, injury or death ("High Risk Product"). By      
including Fujitsu's product in a High Risk Product, the manufacturer        
of such system or application assumes all risk of such use and in doing     
so agrees to indemnify Fujitsu against all liability.                       

 ******************************************************************************/
/******************************************************************************/
/** \file Ssd1351Oled.h
 **
 ** A detailed description is available at 
 ** @link Ssd1351OledGroup OLED with SSD1351 Driver description @endlink
 **
 ** History:
 **   - 2019-01-21  V1.0  MSc  First Version
 **   - 2019-04-02  V1.1  MSc  Adding partly updating display
 *****************************************************************************/
#ifndef __SSD1351OLED_H__
#define __SSD1351OLED_H__

/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C"
{
#endif

/**
 ******************************************************************************
 ** \defgroup Ssd1351OledGroup OLED with SSD1351 Driver
 **
 ** Provided functions of Ssd1351Oled:
 **   - Ssd1351Oled_Init()
 **   - Ssd1351Oled_DisplayOn()
 **   - Ssd1351Oled_DisplayOff()
 **   - Ssd1351Oled_UpdateFramebuffer()
 **   - Ssd1351Oled_RamAddress()
 **   - Ssd1351Oled_FillColor()
 ** 
 **   
 ******************************************************************************/
//@{

/**
 ******************************************************************************    
 ** \page ssd1351oled_module_includes Required includes in main application
 ** \brief Following includes are required
 ** @code   
 ** #include "ssd1351oled.h"   
 ** @endcode
 **
 ******************************************************************************/
    
/*****************************************************************************/
/* Include files                                                             */
/*****************************************************************************/

#include "base_types.h"

/*****************************************************************************/
/* Global pre-processor symbols/macros ('#define')                            */
/*****************************************************************************/

#if __STDC_VERSION__ >= 199901L
   /*C99*/
#else
  /*Not C99*/
  #error Please enable C99 support for the compiler
#endif

#define SSD1351OLED_U16_SWAP(num)                     (((num << 8) & 0xFF00) | ((num >> 8) & 0xFF))
#define SSD1351OLED_WIDTH                             (128)
#define SSD1351OLED_HEIGHT                            (128)
#define SSD1351OLED_FBPOS(x,y)                        ((y)*SSD1351OLED_WIDTH + (x))
#define SSD1351OLED_SETPIXEL(pFrameBuffer,x,y,color)  pFrameBuffer[SSD1351OLED_FBPOS(x,y)].Data = SSD1351OLED_U16_SWAP((color).Data)
#define SSD1351OLED_R_Pos                             (11)
#define SSD1351OLED_R_Mask                            ((0x1F) << SSD1351OLED_R_Pos)
#define SSD1351OLED_G_Pos                             (5)
#define SSD1351OLED_G_Mask                            ((0x3F) << SSD1351OLED_G_Pos)
#define SSD1351OLED_B_Pos                             (0)
#define SSD1351OLED_B_Mask                            ((0x1F) << SSD1351OLED_B_Pos)
#define SSD1351OLED_RGB(r,g,b)                        ((stc_color_t){( \
                                                        (((r >> 3) << SSD1351OLED_R_Pos) & SSD1351OLED_R_Mask) | \
                                                        (((g >> 2) << SSD1351OLED_G_Pos) & SSD1351OLED_G_Mask) | \
                                                        (((b >> 3) << SSD1351OLED_B_Pos) & SSD1351OLED_B_Mask) \
                                                      )})

#define SSD1351OLED_CMD_SETCOLUMN                     0x15
#define SSD1351OLED_CMD_SETROW                        0x75
#define SSD1351OLED_CMD_WRITERAM                      0x5C
#define SSD1351OLED_CMD_READRAM                       0x5D
#define SSD1351OLED_CMD_SETREMAP                      0xA0
#define SSD1351OLED_CMD_STARTLINE                     0xA1
#define SSD1351OLED_CMD_DISPLAYOFFSET 	              0xA2
#define SSD1351OLED_CMD_DISPLAYALLOFF 	              0xA4
#define SSD1351OLED_CMD_DISPLAYALLON  	              0xA5
#define SSD1351OLED_CMD_NORMALDISPLAY 	              0xA6
#define SSD1351OLED_CMD_INVERTDISPLAY 	              0xA7
#define SSD1351OLED_CMD_FUNCTIONSELECT                0xAB
#define SSD1351OLED_CMD_DISPLAYOFF                    0xAE
#define SSD1351OLED_CMD_DISPLAYON     	              0xAF
#define SSD1351OLED_CMD_PRECHARGE                     0xB1
#define SSD1351OLED_CMD_DISPLAYENHANCE                0xB2
#define SSD1351OLED_CMD_CLOCKDIV                      0xB3
#define SSD1351OLED_CMD_SETVSL                        0xB4
#define SSD1351OLED_CMD_SETGPIO 	                  0xB5                
#define SSD1351OLED_CMD_PRECHARGE2                    0xB6
#define SSD1351OLED_CMD_SETGRAY                       0xB8
#define SSD1351OLED_CMD_USELUT                        0xB9
#define SSD1351OLED_CMD_PRECHARGELEVEL                0xBB
#define SSD1351OLED_CMD_VCOMH                         0xBE
#define SSD1351OLED_CMD_CONTRASTABC                   0xC1
#define SSD1351OLED_CMD_CONTRASTMASTER                0xC7
#define SSD1351OLED_CMD_MUXRATIO                      0xCA
#define SSD1351OLED_CMD_COMMANDLOCK                   0xFD
#define SSD1351OLED_CMD_HORIZSCROLL                   0x96
#define SSD1351OLED_CMD_STOPSCROLL                    0x9E
#define SSD1351OLED_CMD_STARTSCROLL                   0x9F

#define SSD1351OLED_GPIO_UNUSED                       (255)

/*
 * Arm Compiler 4/5
 */
#if   defined ( __CC_ARM )
  #ifndef   __INLINE
    #define __INLINE                               __inline
  #endif
  #ifndef   __STATIC_INLINE
    #define __STATIC_INLINE                        static __inline
  #endif
  #ifndef   __STATIC_FORCEINLINE                 
    #define __STATIC_FORCEINLINE                   static __forceinline
  #endif
  #ifndef   __WEAK
    #define __WEAK                                 __attribute__((weak))
  #endif
  #ifndef   __PACKED
    #define __PACKED                               __attribute__((packed))
  #endif
  #ifndef   __PACKED_STRUCT
    #define __PACKED_STRUCT                        __packed struct
  #endif
  #ifndef   __PACKED_UNION
    #define __PACKED_UNION                         __packed union
  #endif
/*
 * Arm Compiler 6 (armclang)
 */
#elif defined (__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
  #ifndef   __INLINE
    #define __INLINE                               __inline
  #endif
  #ifndef   __STATIC_INLINE
    #define __STATIC_INLINE                        static __inline
  #endif
  #ifndef   __STATIC_FORCEINLINE                 
    #define __STATIC_FORCEINLINE                   __attribute__((always_inline)) static __inline
  #endif
  #ifndef   __WEAK
    #define __WEAK                                 __attribute__((weak))
  #endif
  #ifndef   __PACKED
    #define __PACKED                               __attribute__((packed, aligned(1)))
  #endif
  #ifndef   __PACKED_STRUCT
    #define __PACKED_STRUCT                        struct __attribute__((packed, aligned(1)))
  #endif
  #ifndef   __PACKED_UNION
    #define __PACKED_UNION                         union __attribute__((packed, aligned(1)))
  #endif

/*
 * GNU Compiler
 */
#elif defined ( __GNUC__ )
  #ifndef   __INLINE
    #define __INLINE                               inline
  #endif
  #ifndef   __STATIC_INLINE
    #define __STATIC_INLINE                        static inline
  #endif
  #ifndef   __STATIC_FORCEINLINE                 
    #define __STATIC_FORCEINLINE                   __attribute__((always_inline)) static inline
  #endif                                           
  #ifndef   __WEAK
    #define __WEAK                                 __attribute__((weak))
  #endif
  #ifndef   __PACKED
    #define __PACKED                               __attribute__((packed, aligned(1)))
  #endif
  #ifndef   __PACKED_STRUCT
    #define __PACKED_STRUCT                        struct __attribute__((packed, aligned(1)))
  #endif
  #ifndef   __PACKED_UNION
    #define __PACKED_UNION                         union __attribute__((packed, aligned(1)))
  #endif
/*
 * IAR Compiler
 */
#elif defined ( __ICCARM__ )
  #ifndef __IAR_FT
      #define __IAR_FT _Pragma("inline=forced") __intrinsic
  #endif
  #ifndef __ICCARM_V8
      #if (__VER__ >= 8000000)
        #define __ICCARM_V8 1
      #else
        #define __ICCARM_V8 0
      #endif
  #endif
  #ifndef __INLINE
    #define __INLINE inline
  #endif
  #ifndef   __PACKED
    #if __ICCARM_V8
      #define __PACKED __attribute__((packed, aligned(1)))
    #else
      /* Needs IAR language extensions */
      #define __PACKED __packed
    #endif
  #endif

  #ifndef   __PACKED_STRUCT
    #if __ICCARM_V8
      #define __PACKED_STRUCT struct __attribute__((packed, aligned(1)))
    #else
      /* Needs IAR language extensions */
      #define __PACKED_STRUCT __packed struct
    #endif
  #endif
  #ifndef   __PACKED_UNION
    #if __ICCARM_V8
      #define __PACKED_UNION union __attribute__((packed, aligned(1)))
    #else
      /* Needs IAR language extensions */
      #define __PACKED_UNION __packed union
    #endif
  #endif
  #ifndef   __STATIC_INLINE
    #define __STATIC_INLINE       static inline
  #endif

  #ifndef   __FORCEINLINE
    #define __FORCEINLINE         _Pragma("inline=forced")
  #endif

  #ifndef   __STATIC_FORCEINLINE
    #define __STATIC_FORCEINLINE  __FORCEINLINE __STATIC_INLINE
  #endif
  #ifndef   __WEAK
  #if __ICCARM_V8
    #define __WEAK __attribute__((weak))
  #else
    #define __WEAK _Pragma("__weak")
  #endif
#endif
/*
 * TI Arm Compiler
 */
#elif defined ( __TI_ARM__ )
  #ifndef   __INLINE
    #define __INLINE                               inline
  #endif
  #ifndef   __STATIC_INLINE
    #define __STATIC_INLINE                        static inline
  #endif
  #ifndef   __STATIC_FORCEINLINE
    #define __STATIC_FORCEINLINE                   __STATIC_INLINE
  #endif
  #ifndef   __WEAK
    #define __WEAK                                 __attribute__((weak))
  #endif
  #ifndef   __PACKED
    #define __PACKED                               __attribute__((packed))
  #endif
  #ifndef   __PACKED_STRUCT
    #define __PACKED_STRUCT                        struct __attribute__((packed))
  #endif
  #ifndef   __PACKED_UNION
    #define __PACKED_UNION                         union __attribute__((packed))
  #endif
/*
 * TASKING Compiler
 */
#elif defined ( __TASKING__ )
  #ifndef   __INLINE
    #define __INLINE                               inline
  #endif
  #ifndef   __STATIC_INLINE
    #define __STATIC_INLINE                        static inline
  #endif
  #ifndef   __STATIC_FORCEINLINE
    #define __STATIC_FORCEINLINE                   __STATIC_INLINE
  #endif
  #ifndef   __WEAK
    #define __WEAK                                 __weak
  #endif
  #ifndef   __PACKED
    #define __PACKED                               @packed
  #endif
  #ifndef   __PACKED_STRUCT
    #define __PACKED_STRUCT                        @packed struct
  #endif
  #ifndef   __PACKED_UNION
    #define __PACKED_UNION                         @packed union
  #endif
/*
 * COSMIC Compiler
 */
#elif defined ( __CSMC__ )
  #ifndef   __INLINE
    #define __INLINE                               inline
  #endif
  #ifndef   __STATIC_INLINE
    #define __STATIC_INLINE                        static inline
  #endif
  #ifndef   __STATIC_FORCEINLINE
    #define __STATIC_FORCEINLINE                   __STATIC_INLINE
  #endif
  #ifndef   __WEAK
    #define __WEAK                                 __weak
  #endif
  #ifndef   __PACKED
    #define __PACKED                               @packed
  #endif
  #ifndef   __PACKED_STRUCT
    #define __PACKED_STRUCT                        @packed struct
  #endif
  #ifndef   __PACKED_UNION
    #define __PACKED_UNION                         @packed union
  #endif
#else
  #error Unknown compiler.
#endif
/*****************************************************************************/
/* Global type definitions ('typedef')                                        */
/*****************************************************************************/

/* ========================================  Start of section using anonymous unions  ======================================== */
#if defined (__CC_ARM)
  #pragma push
  #pragma anon_unions
#elif defined (__ICCARM__)
  #pragma language=extended
#elif defined(__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
  #pragma clang diagnostic push
  #pragma clang diagnostic ignored "-Wc11-extensions"
  #pragma clang diagnostic ignored "-Wreserved-id-macro"
#elif defined (__GNUC__)
  /* anonymous unions are enabled by default */
#elif defined (__TMS470__)
  /* anonymous unions are enabled by default */
#elif defined (__TASKING__)
  #pragma warning 586
#elif defined (__CSMC__)
  /* anonymous unions are enabled by default */
#else
  #warning Not supported compiler type
#endif

typedef struct stc_color
{
    union
    {
        uint16_t Data;
        struct 
        {
            uint16_t B: 5;
            uint16_t G: 6;
            uint16_t R: 5;
        } RGB_f;
    };
} stc_color_t;

typedef stc_color_t color_t;

typedef en_result_t (*pfn_ssd1351oled_gpio_setclear_t)(uint8_t u8Gpio, boolean_t bSet);
typedef en_result_t (*pfn_ssd1351oled_spi_write_t)(void* pHandle, uint32_t u32Chipselect, uint8_t* pu8Data, uint32_t u32Len);
typedef boolean_t (*pfn_ssd1351oled_spi_checkready_t)(void* pHandle);

typedef struct stc_ssd1351oled_handle
{
    stc_color_t* pFrameBuffer;
    pfn_ssd1351oled_spi_write_t pfSpiWrite;
    pfn_ssd1351oled_spi_checkready_t pfSpiCheckReady;
    pfn_ssd1351oled_gpio_setclear_t pfGpioSetClear;
    void* SpiHandle;
    uint32_t u32Chipselect;
    struct
    {
        uint8_t DIN;
        uint8_t SCK;
        uint8_t CS;
        uint8_t DC;
        uint8_t RST;
    } Gpio;
    struct
    {
        boolean_t bNeedsUpdate;
        int16_t xmin;
        int16_t xmax;
        int16_t ymin;
        int16_t ymax;
    } FrameBufferUpdate;
} stc_ssd1351oled_handle_t;

typedef enum en_ssd1351oled_mode
{
    enSsd1351OledModeDirect,
    enSsd1351OledModeFrameBuffer,
    enSsd1351OledModeFrameBufferAndUpdate
} en_ssd1351oled_mode_t;

/* =========================================  End of section using anonymous unions  ========================================= */
#if defined (__CC_ARM)
  #pragma pop
#elif defined (__ICCARM__)
  /* leave anonymous unions enabled */
#elif (__ARMCC_VERSION >= 6010050)
  #pragma clang diagnostic pop
#elif defined (__GNUC__)
  /* anonymous unions are enabled by default */
#elif defined (__TMS470__)
  /* anonymous unions are enabled by default */
#elif defined (__TASKING__)
  #pragma warning restore
#elif defined (__CSMC__)
  /* anonymous unions are enabled by default */
#endif


/*****************************************************************************/
/* Global variable declarations ('extern', definition in C source)           */
/*****************************************************************************/



/*****************************************************************************/
/* Global function prototypes ('extern', definition in C source)             */
/*****************************************************************************/


en_result_t Ssd1351Oled_DisplayOn(stc_ssd1351oled_handle_t* pstcHandle);
en_result_t Ssd1351Oled_DisplayOff(stc_ssd1351oled_handle_t* pstcHandle);
en_result_t Ssd1351Oled_SetDefaultHandle(stc_ssd1351oled_handle_t* pstcHandle);
en_result_t Ssd1351Oled_Init(stc_ssd1351oled_handle_t* pstcHandle);
en_result_t Ssd1351Oled_UpdateFullFramebuffer(stc_ssd1351oled_handle_t* pstcHandle);
void Ssd1351Oled_UpdatePartFramebuffer(stc_ssd1351oled_handle_t* pstcHandle);
en_result_t Ssd1351Oled_UpdateFramebufferWindow(stc_ssd1351oled_handle_t* pstcHandle,uint16_t xmin, uint16_t ymin, uint16_t xmax, uint16_t ymax);
en_result_t Ssd1351Oled_RamAddress(stc_ssd1351oled_handle_t* pstcHandle);
en_result_t Ssd1351Oled_FillColor(stc_ssd1351oled_handle_t* pstcHandle, stc_color_t stcColor, en_ssd1351oled_mode_t enMode);
en_result_t Ssd1351Oled_FillScreen(stc_ssd1351oled_handle_t* pstcHandle, stc_color_t* pData, en_ssd1351oled_mode_t enMode) ;
void Ssd1351Oled_SetPixel(stc_ssd1351oled_handle_t* pstcHandle, int16_t x,int16_t y,uint32_t c);
void Ssd1351Oled_SetPixelDefaultHandle(int16_t x,int16_t y,uint32_t c);

#ifdef __cplusplus
}
#endif

//@} // Ssd1351OledGroup

#endif /*__SSD1351OLED_H__*/

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/

