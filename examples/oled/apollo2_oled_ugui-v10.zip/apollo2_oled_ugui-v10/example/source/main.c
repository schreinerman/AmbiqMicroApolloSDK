/******************************************************************************

Copyright (C) 2013-2017, Fujitsu Electronics Europe GmbH or a               
subsidiary of Fujitsu Electronics Europe GmbH.  All rights reserved.        
                                                                            
This software, including source code, documentation and related             
materials ("Software"), is owned by Fujitsu Electronics Europe GmbH or      
one of its subsidiaries ("Fujitsu").
                                                                            
If no EULA applies, Fujitsu hereby grants you a personal, non-exclusive,    
non-transferable license to copy, modify, and compile the                   
Software source code solely for use in connection with Fujitsu's            
integrated circuit products.  Any reproduction, modification, translation,  
compilation, or representation of this Software except as specified         
above is prohibited without the express written permission of Fujitsu.      
                                                                            
Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO                        
WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING,                        
BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED                                
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A                             
PARTICULAR PURPOSE. Fujitsu reserves the right to make                      
changes to the Software without notice. Fujitsu does not assume any         
liability arising out of the application or use of the Software or any      
product or circuit described in the Software. Fujitsu does not              
authorize its products for use in any products where a malfunction or       
failure of the Fujitsu product may reasonably be expected to result in      
significant property damage, injury or death ("High Risk Product"). By      
including Fujitsu's product in a High Risk Product, the manufacturer        
of such system or application assumes all risk of such use and in doing     
so agrees to indemnify Fujitsu against all liability.                       

 ******************************************************************************/
/******************************************************************************/
/** \file main.c
 **
 ** A detailed description is available at 
 ** @link mainGroup  description @endlink
 **
 ** History:
 **   - 2017-03-17  V1.0  MSc  Automatic Created
 *****************************************************************************/
#define __MAIN_C__
/*****************************************************************************/
/* Include files                                                             */
/*****************************************************************************/
#include "mcu.h"
#include "base_types.h"
#include "apolloiom.h"
#include "apollogpio.h"
#include "ssd1351oled.h"
#include "string.h"
#include "stdio.h"
#include "ugui.h"
#include "apollosysctrl.h"

/*****************************************************************************/
/* Local pre-processor symbols/macros ('#define')                            */
/*****************************************************************************/


#define GPIO_SSD1351_SCK     39
#define GPIO_SSD1351_MISO    0xFF
#define GPIO_SSD1351_MOSI    44
#define GPIO_SSD1351_CS      17
#define GPIO_SSD1351_DC      14
#define GPIO_SSD1351_RST     15
#define SPI_SSD1351          IOM4
#define SPI_SSD1351_CS       (u8CsChannelSSD1351)
#define SPI_FREQ             24000000UL

/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/


/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/


/*****************************************************************************/
/* Local variable definitions ('static')                                     */
/*****************************************************************************/

static en_result_t SpiWrite(void* pHandle, uint32_t u32Chipselect, uint8_t* pu8Data, uint32_t u32Len);
static boolean_t SpiReady(void* pHandle);

static volatile uint32_t u32Counter;  //ms counter

static uint8_t u8CsChannelSSD1351;

static const stc_apolloiom_config_t stcSpiConfig = {
    IomInterfaceModeSpi,     //Mode: SPI
    SPI_FREQ,                //SPI speed: max. 24MHz       
    FALSE,                   //SPHA
    FALSE,                   //SPOL
    10,                      //Fifo read threshold
    10,                      //Fifo write threshold
    FALSE,                   //Fullduplex
    {
        GPIO_SSD1351_SCK,    //SPI SCK
        GPIO_SSD1351_MISO,   //SPI MISO
        GPIO_SSD1351_MOSI    //SPI MOSI
    }
};

static uint16_t au16FrameBuffer[SSD1351OLED_WIDTH*SSD1351OLED_HEIGHT];

static stc_ssd1351oled_handle_t stcOled = {
    (stc_color_t*)&au16FrameBuffer[0], //pointer to framebuffer
    SpiWrite,                //SPI write function
    SpiReady,                //SPI ready check function
    (pfn_ssd1351oled_gpio_setclear_t)ApolloGpio_GpioSet,      //Set GPIO function
    SPI_SSD1351,             //SPI handle      
    0,                       //chipselect channel (determined later on)
    {
        GPIO_SSD1351_MOSI,   //MOSI pin number
        GPIO_SSD1351_SCK,    //SCK pin number
        0xFF,                //CS pin number (0xFF == not used as GPIO)
        GPIO_SSD1351_DC,     //DC pin number
        GPIO_SSD1351_RST     //RST pin number
    }   
};

static UG_GUI gui;

static volatile boolean_t bNeedsUpdate = FALSE;


/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/


/*****************************************************************************/
/* Function implementation - global ('extern') and local ('static')          */
/*****************************************************************************/

/**
 *********************************************************************************
 ** \brief SPI write function for OLED display
 **  
 ** \param pHandle SPI handle
 **  
 ** \param u32Chipselect chipselect channel
 **  
 ** \param pu8Data pointer to buffer
 **  
 ** \param u32Len buffer len
 **  
 ** \details SPI write function for OLED display
 **  
 *********************************************************************************/
static en_result_t SpiWrite(void* pHandle, uint32_t u32Chipselect, uint8_t* pu8Data, uint32_t u32Len)
{
    ApolloIom_SpiWritePolled(pHandle,u32Chipselect,pu8Data,u32Len,NULL,AM_HAL_IOM_RAW);
    return Ok;
}

/**
 *********************************************************************************
 ** \brief SPI ready function for OLED display
 **  
 ** \param pHandle SPI handle
 **
 ** \return TRUE if ready, else FALSE
 **  
 ** \details SPI write function for OLED display
 **  
 *********************************************************************************/
static boolean_t SpiReady(void* pHandle)
{
    if (ApolloIom_CheckReady(pHandle) == Ok)
    {
        return TRUE;
    }
    return FALSE;
}

/**
 *********************************************************************************
 ** \brief weak delay function used with SysTick IRQ
 **  
 ** \param [in] delayMs Delay in ms
 **  
 ** \details weak delay function used with SysTick IRQ
 **  
 *********************************************************************************/
void delay(uint32_t delayMs) 
{
    uint32_t u32End = u32Counter;
    u32End += delayMs;
    while(u32End != u32Counter) __NOP();
}



/**
 *********************************************************************************
 ** \brief function returning ms counter
 **  
 ** \details function returning ms counter
 **
 ** \returns ms counter
 **  
 *********************************************************************************/
uint32_t milis(void)
{
    return u32Counter;
}

/**
 *********************************************************************************
 ** \brief uGUI Minimal set pixel function
 **
 ** \param x position x
 **
 ** \param y position y
 **
 ** \param c color in RGB888
 **  
 ** \details uGUI set pixel function
 **  
 *********************************************************************************/
void ugui_pixel_set(UG_S16 x,UG_S16 y,UG_COLOR c)
{
    uint16_t tmp;
    if ((x >= SSD1351OLED_WIDTH) || (y >= SSD1351OLED_HEIGHT)) return;
    tmp =  (c >> 3) & 0x001F;
    tmp |= (c >> 5) & 0x07E0;
    tmp |= (c >> 8) & 0xF800;
    ((uint8_t*)au16FrameBuffer)[(x + y*SSD1351OLED_WIDTH)*2] = (tmp >> 8) & 0xFF;
    ((uint8_t*)au16FrameBuffer)[(x + y*SSD1351OLED_WIDTH)*2+1] = tmp & 0xFF;
    bNeedsUpdate = TRUE;
}

/**
 *********************************************************************************
 **
 ** \brief Update uGUI 
 **
 *********************************************************************************/
void Update_uGUI(void)
{
    UG_Update();
    Ssd1351Oled_UpdatePartFramebuffer(&stcOled);
    
    //Uncomment if redrawing whole framebuffer is required
    //if (bNeedsUpdate == TRUE)
    //{
    //    Ssd1351Oled_UpdateFullFramebuffer(&stcOled);
    //    bNeedsUpdate = FALSE;
    //}
}

/**
 *****************************************************************************
 ** 
 **\brief Systick interrupt handler defined by CMSIS
 **
 *****************************************************************************/
void SysTick_Handler(void)
{
	u32Counter++;
}



/**
 *****************************************************************************
 ** 
 **\brief Main function
 **
 *****************************************************************************/
int main(void)
{
    int i,j,k;
    uint8_t au8Buffer[10];

    //
    //application initialization area
    //
    
    SystemCoreClockUpdate();                //update clock variable SystemCoreClock (defined by CMSIS)
    SysTick_Config(SystemCoreClock / 1000); //setup 1ms SysTick (defined by CMSIS)

    //enable flash cache
    ApolloSysctrl_EnableCache();
    
    //initialize GPIOs
    ApolloGpio_GpioOutputEnable(GPIO_SSD1351_DC,TRUE);
    ApolloGpio_GpioOutputEnable(GPIO_SSD1351_RST,TRUE);
    //not used as GPIO: ApolloGpio_GpioOutputEnable(GPIO_SSD1351_CS,TRUE);

    //initialize chipselect
    ApolloIOM_InitSpiCs(SPI_SSD1351,GPIO_SSD1351_CS,&u8CsChannelSSD1351);
    stcOled.u32Chipselect = u8CsChannelSSD1351;

    //configure and enable SPI
    ApolloIOM_Configure(SPI_SSD1351,&stcSpiConfig);
    ApolloIOM_Enable(SPI_SSD1351);

    //init OLED
    Ssd1351Oled_Init(&stcOled);

    //init uGUI
    UG_Init(&gui,(void(*)(UG_S16,UG_S16,UG_COLOR))ugui_pixel_set,SSD1351OLED_WIDTH,SSD1351OLED_HEIGHT);
    

    while(1)
    {
        //reset OLED (black)
        Ssd1351Oled_FillColor(&stcOled,SSD1351OLED_RGB(0,0,0),enSsd1351OledModeFrameBufferAndUpdate);

        //
        // START - uGUI Example
        // 
        UG_FillCircle(10,10,5,C_RED);
        UG_FillCircle(16,20,5,C_GREEN);
        UG_FillCircle(18,12,5,C_BLUE);
        UG_FontSelect(&FONT_10X16);
        UG_SetForecolor(C_WHITE);
        UG_PutString(5,30,"Hello World");
        UG_PutString(5,105,"uGUI Demo");
        UG_SetForecolor(C_GREEN);
        UG_FontSelect(&FONT_32X53);
        for(i = 9;i >= 0;i--)
        {
            if (i == 6) UG_SetForecolor(C_ORANGE);
            if (i == 3) UG_SetForecolor(C_RED);
            sprintf((char*)au8Buffer,"%d ",i);
            UG_PutString(50,50,(char*)au8Buffer);
            
            Update_uGUI();
            delay(1000);
        }

        //
        // END - uGUI Example
        // 

        //
        // START - Framebuffer tests
        // 

        //fade in red screen
        for(i = 0;i < 256;i+=4)
        {
            Ssd1351Oled_FillColor(&stcOled,SSD1351OLED_RGB(i,0,0),enSsd1351OledModeFrameBufferAndUpdate);
        }
        //fade out red screen
        for(i = 0;i < 256;i+=4)
        {
            Ssd1351Oled_FillColor(&stcOled,SSD1351OLED_RGB(255-i,0,0),enSsd1351OledModeFrameBufferAndUpdate);
        }

        //fade in green screen
        for(i = 0;i < 256;i+=4)
        {
            Ssd1351Oled_FillColor(&stcOled,SSD1351OLED_RGB(0,i,0),enSsd1351OledModeFrameBufferAndUpdate);
        }

        //fade out green screen
        for(i = 0;i < 256;i+=4)
        {
            Ssd1351Oled_FillColor(&stcOled,SSD1351OLED_RGB(0,255-i,0),enSsd1351OledModeFrameBufferAndUpdate);
        }
        

        //fade in blue screen
        for(i = 0;i < 256;i+=4)
        {
            Ssd1351Oled_FillColor(&stcOled,SSD1351OLED_RGB(0,0,i),enSsd1351OledModeFrameBufferAndUpdate);
        }

        //fade out blue screen
        for(i = 0;i < 256;i+=4)
        {
            Ssd1351Oled_FillColor(&stcOled,SSD1351OLED_RGB(0,0,255-i),enSsd1351OledModeFrameBufferAndUpdate);
        }
        
        for(k = 0; k < 10;k++)
        {
          //draw rects
          for(j = 2;j < 64;j+=2)
          {
              for(i = j;i < (128 - j);i+=1)
              {
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,i,j,SSD1351OLED_RGB(0xFF,0xFF,0xFF));
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,i,(128 - j),SSD1351OLED_RGB(0xFF,0xFF,0xFF));
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,j,i,SSD1351OLED_RGB(0xFF,0xFF,0xFF));
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,(128 - j),i,SSD1351OLED_RGB(0xFF,0xFF,0xFF));
              }

              //update framebuffer after drawing
              Ssd1351Oled_UpdateFullFramebuffer(&stcOled);
          }
          for(j = 2;j < 64;j+=2)
          {
              for(i = j;i < (128 - j);i+=1)
              {
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,i,j,SSD1351OLED_RGB(0,0,0));
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,i,(128 - j),SSD1351OLED_RGB(0,0,0));
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,j,i,SSD1351OLED_RGB(0,0,0));
                  SSD1351OLED_SETPIXEL(stcOled.pFrameBuffer,(128 - j),i,SSD1351OLED_RGB(0,0,0));
              }

              //update framebuffer after drawing
              Ssd1351Oled_UpdateFullFramebuffer(&stcOled);
          }
        }
        //
        // END - Framebuffer tests
        // 
    }
}



/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/

